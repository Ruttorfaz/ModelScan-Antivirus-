# ModelScan — AI "Antivirus"

Tool open-source per scansionare file modello ML alla ricerca di artefatti sospetti e per eseguire una batteria base di test di integrità e robustezza.

## Installazione

```bash
git clone https://github.com/<tuo-username>/modelscan-ai-antivirus.git
cd modelscan-ai-antivirus
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Uso (CLI)

```bash
modelscan scan samples/eicar_model_like.pkl --output report.json
modelscan web --host 0.0.0.0 --port 5000
```
