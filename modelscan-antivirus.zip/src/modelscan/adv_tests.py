class AdvTests:
    def __init__(self):
        self.available = False
        try:
            import art
            self.available = True
        except Exception:
            self.available = False

    def run_basic_tests(self, path: str) -> dict:
        if not self.available:
            return {"skipped": True, "reason": "ART non installato"}
        return {"skipped": True, "reason": "nessun test specifico configurato"}
