import os
import re
import magic

SUSPICIOUS_PATTERNS = [
    rb"\bexec\b",
    rb"\beval\b",
    rb"\bos\.system\b",
    rb"\bsubprocess\b",
    rb"\bsocket\b",
    rb"\brequests\b",
]

class StaticScanner:
    def scan(self, path: str) -> dict:
        result = {"path": path, "warnings": [], "meta": {}}
        if not os.path.exists(path):
            result["warnings"].append("file not found")
            return result
        try:
            mtype = magic.from_file(path, mime=True)
            result["meta"]["mime"] = mtype
        except Exception:
            result["meta"]["mime"] = "unknown"
        try:
            with open(path, "rb") as f:
                data = f.read()
            for p in SUSPICIOUS_PATTERNS:
                if re.search(p, data):
                    result["warnings"].append(f"pattern sospetto: {p.decode('utf-8', errors='ignore')}")
        except Exception as e:
            result["warnings"].append(f"read error: {e}")
        return result
