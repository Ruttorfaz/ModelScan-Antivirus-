import json
from .static_scanner import StaticScanner
from .adv_tests import AdvTests

class ModelScanner:
    def __init__(self, config=None):
        self.static = StaticScanner()
        self.adv = AdvTests()
        self.config = config or {}

    def scan_file(self, path: str) -> dict:
        report = {
            "path": path,
            "static": self.static.scan(path),
            "adv": None
        }
        if self.config.get("run_adv_tests"):
            report["adv"] = self.adv.run_basic_tests(path)
        return report

    def scan_to_file(self, path: str, out_json: str):
        report = self.scan_file(path)
        with open(out_json, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
        return out_json
