from flask import Flask, request, render_template_string, jsonify
from .scanner import ModelScanner

TEMPLATE = """
<html>
  <head><title>ModelScan Demo</title></head>
  <body>
    <h1>ModelScan Demo</h1>
    <form action="/scan" method="post" enctype="multipart/form-data">
      <input type="file" name="modelfile" />
      <input type="submit" value="Scan" />
    </form>
  </body>
</html>
"""

def create_app():
    app = Flask(__name__)

    @app.route('/')
    def index():
        return render_template_string(TEMPLATE)

    @app.route('/scan', methods=['POST'])
    def scan():
        f = request.files.get('modelfile')
        if not f:
            return jsonify({'error': 'no file'}), 400
        import tempfile
        tmp = tempfile.NamedTemporaryFile(delete=False)
        f.save(tmp.name)
        ms = ModelScanner()
        report = ms.scan_file(tmp.name)
        return jsonify(report)

    return app
