import click
from .scanner import ModelScanner

@click.group()
def cli():
    pass

@cli.command()
@click.argument('path')
@click.option('--output', '-o', default='report.json')
@click.option('--run-adv/--no-adv', default=False)
def scan(path, output, run_adv):
    cfg = {"run_adv_tests": run_adv}
    ms = ModelScanner(config=cfg)
    out = ms.scan_to_file(path, output)
    click.echo(f"Report scritto in: {out}")

@cli.command()
@click.option('--host', default='127.0.0.1')
@click.option('--port', default=5000)
def web(host, port):
    from .webapp import create_app
    app = create_app()
    app.run(host=host, port=port)

if __name__ == '__main__':
    cli()
