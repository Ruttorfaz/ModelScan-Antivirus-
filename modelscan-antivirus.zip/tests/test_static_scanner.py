from modelscan.static_scanner import StaticScanner

def test_scan_sample(tmp_path):
    p = tmp_path / "sample.pkl"
    p.write_bytes(b"This is a harmless PICKLE-like file with exec as text")
    s = StaticScanner()
    r = s.scan(str(p))
    assert 'warnings' in r
